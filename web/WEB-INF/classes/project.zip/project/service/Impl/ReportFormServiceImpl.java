package project.service.Impl;//package project.service.Impl;
//
//import project.DAL.Factory.Dao.Impl.ReportFormDaoImpl;
//import project.entity.ReportForm;
//import project.service.ReportFormService;
//
//import java.util.List;
//
//public class ReportFormServiceImpl implements ReportFormService {
//
//
//    @Override
//    public List<ReportForm> getReportFormList(String student_Id, String teacher_Id, String doctor_Id, String diagnose_Message, String diagnose_String report_Date) {
//        return new ReportFormDaoImpl().getReportFormList(repo_id,student_Id,teacher_Id,doctor_Id,diagnose_Message,report_Date);
//
//    }
//}
