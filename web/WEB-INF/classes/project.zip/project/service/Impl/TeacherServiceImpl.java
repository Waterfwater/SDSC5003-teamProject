package project.service.Impl;

import project.DAL.Factory.Dao.TeacherDao;
import project.DAL.Factory.TeacherDaoFactory;
import project.entity.Teacher;
import project.service.TeacherService;

import java.util.List;

public class TeacherServiceImpl implements TeacherService {
    private static TeacherDao teacherDao = TeacherDaoFactory.getTeacherDaoInstance();
    @Override
    public List<Teacher> getTeacherList(String id, String className) {
        return teacherDao.getTeacherList(id,className);
    }

    @Override
    public int getTotalNum(String id, String className) {
        return teacherDao.getTotalNum(id,className);
    }
}
