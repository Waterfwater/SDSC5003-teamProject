package project.service;

public interface LoginService {
    String login(String id,String passwd);
}
