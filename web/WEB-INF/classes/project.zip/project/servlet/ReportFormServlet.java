package project.servlet;//package project.servlet;
//
//import project.entity.PageBean;
//import project.entity.ReportForm;
//import project.entity.ResponseMessage;
//import project.service.Impl.ReportFormServiceImpl;
//
//import javax.servlet.ServletException;
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import java.io.IOException;
//import java.util.List;
//
//@WebServlet("/ReportForm")
//public class ReportFormServlet extends HttpServlet {
//    @Override
//    public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
//
//        resp.setContentType("text/html;Charset=UTF-8");
//
//        String student_Id = req.getParameter("student_Id");
//        String teacher_Id = req.getParameter("teacher_Id");
//        String doctor_Id = req.getParameter("doctor_Id");
//        String diagnose_Message = req.getParameter("diagnose_Message");
//        String report_Date = req.getParameter("report_Date");
//        String repo_id = req.getParameter("repo_id");
//
//
//
//
//
//
//
//    }
//}
//
