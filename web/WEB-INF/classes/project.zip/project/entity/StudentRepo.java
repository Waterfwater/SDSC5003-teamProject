package project.entity;

public class StudentRepo {
    private String studentName;
    private String doctorName;
    private String appointmentTime;
    private String location;
}
